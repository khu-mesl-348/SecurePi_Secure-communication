
/usr/local/ssl/bin/openssl s_client -connect 127.0.0.1:42422 -cert test.cert -key test.key -keyform engine -engine tpm -verify 2
